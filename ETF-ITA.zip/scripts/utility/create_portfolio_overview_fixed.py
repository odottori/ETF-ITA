#!/usr/bin/env python3
"""
Create Portfolio Overview - ETF Italia Project v10
Crea vista portfolio_overview per backtest e stress test
"""

import sys
import os
import duckdb
from datetime import datetime

# Aggiungi root al path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def create_portfolio_overview():
    """Crea vista portfolio_overview per backtest e stress test"""
    
    print("📊 CREATE PORTFOLIO OVERVIEW - ETF Italia Project v10")
    print("=" * 60)
    
    db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'etf_data.duckdb')
    
    conn = duckdb.connect(db_path)
    
    try:
        # Inizia transazione
        conn.execute("BEGIN TRANSACTION")
        
        print("📊 Creazione vista portfolio_overview...")
        
        # Crea vista portfolio_overview
        conn.execute("""
        CREATE OR REPLACE VIEW portfolio_overview AS
        SELECT 
            date,
            symbol,
            adj_close,
            volume,
            market_value,
            qty,
            cash
        FROM (
            SELECT 
                date,
                symbol,
                ANY_VALUE(adj_close) as adj_close,
                SUM(volume) as volume,
                COALESCE(SUM(adj_close * qty) OVER (PARTITION BY date ORDER BY symbol), 0) as market_value,
                COALESCE(SUM(qty) OVER (PARTITION BY date ORDER BY symbol), 0) as qty,
                0 as cash
            FROM (
                SELECT 
                    m.date,
                    m.symbol,
                    m.adj_close,
                    m.volume,
                    COALESCE(fl.qty, 0) as qty
                FROM market_data m
                LEFT JOIN fiscal_ledger fl ON m.date = fl.date AND m.symbol = fl.symbol
                WHERE m.symbol IN ('CSSPX.MI', 'XS2L.MI')
            ) t
            GROUP BY date, symbol
        ) t2
        ORDER BY date, symbol
        """)
        
        print("✅ Vista portfolio_overview creata")
        
        # Crea vista portfolio_summary per aggregati giornalieri
        conn.execute("""
        CREATE OR REPLACE VIEW portfolio_summary AS
        SELECT 
            date,
            SUM(market_value) as total_market_value,
            SUM(cash) as total_cash,
            SUM(market_value + cash) as total_value,
            AVG(adj_close) as avg_adj_close,
            COUNT(DISTINCT symbol) as symbols_count
        FROM portfolio_overview
        GROUP BY date
        ORDER BY date
        """)
        
        print("✅ Vista portfolio_summary creata")
        
        conn.commit()
        
        print(f"\n🎉 PORTFOLIO OVERVIEW CREATION COMPLETED")
        
        return True
        
    except Exception as e:
        print(f"❌ Errore creazione portfolio overview: {e}")
        try:
            conn.rollback()
        except:
            pass
        return False
        
    finally:
        conn.close()

if __name__ == "__main__":
    success = create_portfolio_overview()
    sys.exit(0 if success else 1)
