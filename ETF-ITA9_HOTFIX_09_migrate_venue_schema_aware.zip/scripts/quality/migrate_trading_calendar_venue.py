#!/usr/bin/env python3
"""Migrate trading_calendar rows from one venue to another (schema-aware).

Background
----------
Different project/DB versions may expose different trading_calendar schemas
(e.g. some DBs don't have a 'comment' column). This script introspects columns
at runtime and builds a compatible INSERT.

Safe defaults
-------------
By default the script performs a *merge*:
- it inserts into the target venue only the dates that are missing in the target
- it does NOT overwrite existing target rows

Use --overwrite to replace target rows for dates present in the source.

Usage
-----
# dry-run
py scripts/quality/migrate_trading_calendar_venue.py --from BIT --to XMIL

# apply (merge)
py scripts/quality/migrate_trading_calendar_venue.py --from BIT --to XMIL --apply

# apply (overwrite target rows for source dates)
py scripts/quality/migrate_trading_calendar_venue.py --from BIT --to XMIL --apply --overwrite

# optionally drop the source venue after migration
py scripts/quality/migrate_trading_calendar_venue.py --from BIT --to XMIL --apply --drop-source
"""

from __future__ import annotations

import argparse
from pathlib import Path
import duckdb

from scripts.utils.path_manager import get_path_manager


def _tc_columns(con: duckdb.DuckDBPyConnection) -> list[str]:
    cols = con.execute("PRAGMA table_info('trading_calendar')").fetchall()
    return [c[1] for c in cols]


def _build_copy_sql(colnames: list[str], merge: bool) -> str:
    if 'date' not in colnames or 'venue' not in colnames:
        raise RuntimeError("trading_calendar must contain columns: date, venue")

    insert_cols = ", ".join(colnames)

    select_expr = []
    for c in colnames:
        if c == 'venue':
            select_expr.append("? AS venue")
        else:
            select_expr.append(c)
    select_cols = ", ".join(select_expr)

    if merge:
        # insert only dates missing in target
        return (
            f"INSERT INTO trading_calendar ({insert_cols}) "
            f"SELECT {select_cols} "
            f"FROM trading_calendar "
            f"WHERE venue=? AND date NOT IN (SELECT date FROM trading_calendar WHERE venue=?)"
        )
    # overwrite mode handled via DELETE then INSERT
    return f"INSERT INTO trading_calendar ({insert_cols}) SELECT {select_cols} FROM trading_calendar WHERE venue=?"


def main() -> int:
    ap = argparse.ArgumentParser(description="Migrate trading_calendar rows from one venue to another (schema-aware)")
    ap.add_argument("--from", dest="from_venue", required=True, help="Source venue (e.g. BIT)")
    ap.add_argument("--to", dest="to_venue", required=True, help="Target venue (e.g. XMIL)")
    ap.add_argument("--apply", action="store_true", help="Apply changes (default: dry-run)")
    ap.add_argument("--overwrite", action="store_true", help="Overwrite target rows for dates present in source")
    ap.add_argument("--drop-source", action="store_true", help="Delete source venue rows after migration")
    args = ap.parse_args()

    pm = get_path_manager()
    db_path = Path(pm.db_path)
    con = duckdb.connect(str(db_path))

    try:
        src_n = con.execute("SELECT COUNT(*) FROM trading_calendar WHERE venue=?", [args.from_venue]).fetchone()[0]
        dst_n = con.execute("SELECT COUNT(*) FROM trading_calendar WHERE venue=?", [args.to_venue]).fetchone()[0]

        print("MIGRATE TRADING CALENDAR VENUE")
        print("=" * 80)
        print(f"DB:   {db_path}")
        print(f"From: {args.from_venue} (rows={src_n})")
        print(f"To:   {args.to_venue} (rows={dst_n})")
        print(f"Mode: {'OVERWRITE' if args.overwrite else 'MERGE'}")

        if src_n == 0:
            print("Nothing to do: source venue has 0 rows.")
            return 0

        colnames = _tc_columns(con)

        if not args.apply:
            print("DRY-RUN: nessuna modifica applicata. Usa --apply per migrare.")
            print("(Info) trading_calendar columns detected:", ", ".join(colnames))
            return 0

        if args.overwrite:
            con.execute(
                "DELETE FROM trading_calendar WHERE venue=? AND date IN (SELECT date FROM trading_calendar WHERE venue=?)",
                [args.to_venue, args.from_venue],
            )
            sql = _build_copy_sql(colnames, merge=False)
            con.execute(sql, [args.to_venue, args.from_venue])
        else:
            sql = _build_copy_sql(colnames, merge=True)
            # params: to_venue, from_venue, to_venue
            con.execute(sql, [args.to_venue, args.from_venue, args.to_venue])

        if args.drop_source:
            con.execute("DELETE FROM trading_calendar WHERE venue=?", [args.from_venue])
            print(f"Dropped source venue rows: {args.from_venue}")

        dst_after = con.execute("SELECT COUNT(*) FROM trading_calendar WHERE venue=?", [args.to_venue]).fetchone()[0]
        src_after = con.execute("SELECT COUNT(*) FROM trading_calendar WHERE venue=?", [args.from_venue]).fetchone()[0]

        print(f"Applied. Target rows after: {dst_after} (was {dst_n})")
        print(f"Source rows after: {src_after} (was {src_n})")
        return 0
    finally:
        con.close()


if __name__ == "__main__":
    raise SystemExit(main())
