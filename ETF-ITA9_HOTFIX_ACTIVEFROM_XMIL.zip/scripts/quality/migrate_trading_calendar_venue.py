#!/usr/bin/env python3
"""Migrate trading_calendar rows from one venue to another.

Uso tipico:
  py scripts/quality/migrate_trading_calendar_venue.py --from BIT --to XMIL --apply

Per default esegue un dry-run.
"""

from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))

import duckdb

from scripts.utils.path_manager import get_path_manager


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="from_venue", type=str, default="BIT", help="Venue sorgente")
    ap.add_argument("--to", dest="to_venue", type=str, default=os.environ.get("ETF_VENUE", "XMIL"), help="Venue destinazione")
    ap.add_argument("--apply", action="store_true", help="Applica modifiche (default: dry-run)")
    args = ap.parse_args()

    pm = get_path_manager()
    db_path = pm.db_path

    con = duckdb.connect(str(db_path))
    try:
        src = con.execute(
            "SELECT COUNT(*) FROM trading_calendar WHERE venue=?",
            [args.from_venue],
        ).fetchone()[0]
        dst = con.execute(
            "SELECT COUNT(*) FROM trading_calendar WHERE venue=?",
            [args.to_venue],
        ).fetchone()[0]

        print("MIGRATE TRADING CALENDAR VENUE")
        print("=" * 80)
        print(f"DB: {db_path}")
        print(f"From: {args.from_venue} (rows={src})")
        print(f"To:   {args.to_venue} (rows={dst})")

        if src == 0:
            print("❌ Nessuna riga sorgente trovata: nulla da migrare")
            return 2

        if not args.apply:
            print("DRY-RUN: nessuna modifica applicata. Usa --apply per migrare.")
            return 0

        # Migrazione: upsert semplice (insert or replace via delete+insert)
        # 1) cancella eventuali righe già presenti nel target per le stesse date
        con.execute(
            "DELETE FROM trading_calendar WHERE venue=? AND date IN (SELECT date FROM trading_calendar WHERE venue=?)",
            [args.to_venue, args.from_venue],
        )
        # 2) copia
        con.execute(
            "INSERT INTO trading_calendar SELECT date, ?, is_open, quality_flag, comment, updated_at FROM trading_calendar WHERE venue=?",
            [args.to_venue, args.from_venue],
        )

        dst2 = con.execute(
            "SELECT COUNT(*) FROM trading_calendar WHERE venue=?",
            [args.to_venue],
        ).fetchone()[0]
        print(f"✅ Migrazione completata. Target rows={dst2}")
        return 0
    finally:
        con.close()


if __name__ == "__main__":
    raise SystemExit(main())
