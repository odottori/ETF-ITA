# Design Document: Holding Period Dinamico + Portfolio Construction

**Versione:** 2.0  
**Data:** 2026-01-07  
**Autore:** Sistema ETF-ITA v10  
**Status:** ENGINEERING READY (invariants vincolanti)

---

## 1. EXECUTIVE SUMMARY

### 1.1 Gap Architetturali Identificati

Il sistema attuale presenta due gap critici che spiegano l'execution rate basso (3.59%) e il cash gating cronico:

1. **Mancanza di Holding Period Dinamico**
   - Le posizioni restano aperte indefinitamente fino a RISK_OFF o stop-loss
   - Nessun "exit pianificato" → portfolio sempre fully invested
   - Nessun "riesame scenario" a scadenza prevista

2. **Mancanza di Portfolio Construction Logic**
   - Con N segnali RISK_ON simultanei, nessun criterio di selezione
   - Nessuna logica di allocation quando ci sono già posizioni aperte
   - Nessun constraint su max posizioni o cash reserve

### 1.2 Soluzione Proposta

Implementare un'architettura integrata che include:

- **Holding Period Dinamico**: durata investimento calcolata da risk_scalar, volatility, momentum
- **Portfolio Construction**: ranking candidati, selezione top-N, allocation disciplinata
- **Cash Rotation**: exit pianificati liberano cash per nuovi entry
- **Riesame Scenario**: a scadenza holding, rivalutazione se estendere o uscire

### 1.3 Impatto Atteso (con limiti dichiarati)

**Metriche target:**
- **Execution rate:** da 3.59% a 12-18% (definizione rigorosa: § 3.1)
- **Cash gating:** eliminato (reserve 10% + exit pianificati)
- **Disciplina operativa:** holding period esplicito + riesame periodico

**Disclaimer:**
> Le stime di execution rate sono proiezioni basate su analisi storica periodo 2025-01-05 → 2026-01-05, e saranno validate con backtest completo su finestra 365gg, con cost model realistico (commissioni 0.19%, slippage 2-5bps volatility-adjusted).
> 
> **L'obiettivo primario è robustezza e coerenza economica; performance è secondaria.**
> 
> I numeri potrebbero non tornare al primo colpo: il sistema è progettato per iterazione disciplinata, non per ottimizzazione prematura.

---

## 2. CONTRACT & INVARIANTS (VINCOLANTI)

### 2.1 Price Convention (TRADING-CRITICAL)

**Invariant P1: Source of Truth per Prezzi**

```
SEGNALI (strategy logic):     adj_close  (dividend-adjusted)
VALORIZZAZIONE (ledger):      close      (actual market price)
EXECUTION PRICE (backtest):   close      (same-day close, conservative)
EXECUTION PRICE (production): close      (market order, best effort)
```

**Razionale:**
- `adj_close` per segnali: coerenza temporale con dividends reinvestiti
- `close` per ledger: matching con broker statement
- `close` per execution: conservativo (no look-ahead bias)

**Test vincolante:**
```python
# Nessuna query può usare adj_close per valorizzazione
assert "adj_close" not in ledger_valuation_query
assert "close" not in signal_generation_query  # Solo adj_close
```

### 2.2 MANDATORY vs OPPORTUNISTIC (ARCHITETTURALE)

**Invariant M1: Separazione Logica Decisionale**

```
MANDATORY (non filtrati da score):
  - RISK_OFF:           signal_state == 'RISK_OFF' → SELL immediato
  - Stop-loss:          drawdown < -15% → SELL immediato
  - Force rebalance:    deviation > 5% AND days_held > min_holding → rebalance
  - Cash insufficiente: pre-trade check HARD (blocca esecuzione)

OPPORTUNISTIC (filtrati da score + holding):
  - Entry:              momentum_score >= score_entry_min (0.7)
  - Rebalance fine:     trade_score >= score_rebalance_min (0.6)
  - ADD posizione:      new_score >= old_score * 1.2 AND days_held > 50% holding
```

**Razionale:**
- MANDATORY: risk management, non negoziabile
- OPPORTUNISTIC: capital allocation, ottimizzabile

**Test vincolante:**
```python
# MANDATORY non deve essere bloccato da score
assert risk_off_orders_executed == risk_off_signals_count
assert stop_loss_orders_executed == stop_loss_triggers_count
```

### 2.3 Costi/Tasse: Informazione, Non Gating (ECONOMICO)

**Invariant C1: Cost Model come Reporting/Penalty**

```
COST/SLIPPAGE/TAX:
  - Usati per: reporting KPI, tie-break tra candidati pari-score, penalty nello score
  - NON usati per: bloccare ordini a priori con logica "alpha > costs"
  
TASSE REALIZZATE:
  - Calcolate: solo in execution/backtest (post-decisione)
  - Zainetto: gestito per categoria fiscale (DIPF §6.2)
  - NON usati per: pseudo-alpha monetario che blocca entry
```

**Razionale:**
- Score euristico (0-1) per decisioni
- Costi monetari per reporting e validazione ex-post

**Test vincolante:**
```python
# Nessun ordine deve essere rifiutato per "alpha < costs"
assert "alpha" not in order_rejection_reasons
assert all(r in ['CASH_INSUFFICIENTE', 'POSITION_INSUFFICIENTE', 'SCORE_TOO_LOW'] 
           for r in rejection_reasons)
```

### 2.4 Run Identity & Audit Trail (REPRODUCIBILITÀ)

**Invariant R1: Tracciabilità Completa**

```
OGNI RUN DEVE AVERE:
  - run_id:           UUID univoco (formato: "backtest_YYYYMMDD_HHMMSS" o UUID4)
  - run_type:         'BACKTEST' | 'PRODUCTION'
  - config_snapshot:  Hash SHA256 o JSON completo dei parametri usati
  - decision_path:    'MANDATORY' | 'OPPORTUNISTIC' per ogni ordine
  - reason_code:      Codice strutturato (es. 'EXIT_RISK_OFF', 'ENTRY_SCORE_OK')
```

**Razionale:**
- Ogni investigazione futura deve essere riproducibile
- Nessuna "opinione", solo fatti tracciabili

**Test vincolante:**
```python
# Ogni record ledger deve avere run_id e reason_code
assert all(row['run_id'] is not None for row in ledger)
assert all(row['reason_code'] in VALID_REASON_CODES for row in ledger)
```

### 2.5 Pre-Trade Checks HARD (PROTEZIONE LEDGER)

**Invariant T1: Nessun Ordine Impossibile nel Ledger**

```
PRE-TRADE CHECKS (bloccanti):
  BUY:
    - cash_required = qty * price + fees + slippage
    - IF cash_available < cash_required: REJECT
    - IF cash_available - cash_required < cash_reserve: REJECT
  
  SELL:
    - IF qty_requested > qty_available: REJECT
    - IF qty_available <= 0: REJECT
  
  QUANTITY:
    - IF qty <= 0: REJECT
    - IF qty * price < min_trade_value: REJECT (se configurato)
```

**Razionale:**
- Il ledger non deve mai contenere operazioni impossibili
- Pre-trade checks PRIMA di scrivere, non dopo

**Test vincolante:**
```python
# Nessun cash negativo dopo reserve
assert all(cash_after_trade >= portfolio_value * min_reserve for trade in ledger)
# Nessun oversell
assert all(position_after_sell >= 0 for sell in sells)
```

### 2.6 Execution Rate: Definizione Rigorosa (FALSIFICABILE)

**Invariant E1: Metrica Univoca**

```
execution_rate = executed_orders / eligible_trading_days

Dove:
  executed_orders:        COUNT(DISTINCT date) WHERE type IN ('BUY','SELL') 
                          AND run_type = 'BACKTEST'
                          AND date BETWEEN start_date AND end_date
  
  eligible_trading_days:  COUNT(DISTINCT date) FROM signals 
                          WHERE date BETWEEN start_date AND end_date

Esclusioni:
  - DEPOSIT/INTEREST:     non contano come "executed orders"
  - Rejected orders:      non contano (non entrano nel ledger)
  - Festività/weekend:    esclusi (solo trading days con segnali)
```

**Razionale:**
- Definizione univoca, non ambigua
- Falsificabile: basta contare righe nel ledger

**Test vincolante:**
```python
# Execution rate deve essere calcolabile deterministicamente
exec_rate_v1 = calculate_execution_rate_method_a()
exec_rate_v2 = calculate_execution_rate_method_b()
assert abs(exec_rate_v1 - exec_rate_v2) < 0.01  # Max 1% discrepanza
```

---

## 3. ARCHITETTURA HOLDING PERIOD DINAMICO

### 2.1 Principio Base

La durata dell'investimento deve essere una **funzione delle condizioni di rischio**, esattamente come il sizing (qty).

**Formula:**
```
holding_days = base_holding * risk_adjustment * volatility_adjustment * momentum_adjustment
```

Dove:
- `base_holding = 90 giorni` (default 3 mesi, parametrizzabile)
- `risk_adjustment = f(risk_scalar)` → scenario stabile = holding lungo
- `volatility_adjustment = f(volatility)` → volatilità alta = holding breve
- `momentum_adjustment = f(momentum_score)` → trend forte = holding lungo

**Range operativo (retail-grade):**
- `min_holding_days = 30` (1 mese minimo, evita overtrading)
- `max_holding_days = 180` (6 mesi massimo, evita posizioni "dimenticate")

### 2.2 Formule Dettagliate

#### A. Risk Adjustment
```python
risk_adjustment = 0.5 + (risk_scalar * 0.5)  # Range: 0.5-1.0
```

**Razionale:**
- `risk_scalar = 1.0` → `risk_adj = 1.0` (massima convinzione → holding pieno)
- `risk_scalar = 0.5` → `risk_adj = 0.75` (media convinzione → holding ridotto 25%)
- `risk_scalar = 0.2` → `risk_adj = 0.6` (bassa convinzione → holding ridotto 40%)

#### B. Volatility Adjustment
```python
if volatility > 0.20:  # > 20%
    vol_adj = 0.7      # Holding ridotto 30%
elif volatility > 0.15:  # 15-20%
    vol_adj = 0.85     # Holding ridotto 15%
else:  # < 15%
    vol_adj = 1.0      # Holding pieno
```

**Razionale:**
- Volatilità alta → scenario instabile → holding breve (ridurre esposizione temporale)
- Volatilità bassa → scenario stabile → holding lungo (massimizzare esposizione)

#### C. Momentum Adjustment
```python
momentum_adj = 0.7 + (momentum_score * 0.3)  # Range: 0.7-1.0
```

**Razionale:**
- `momentum_score = 0.8` → `momentum_adj = 0.94` (trend forte → holding quasi pieno)
- `momentum_score = 0.5` → `momentum_adj = 0.85` (trend medio → holding ridotto 15%)
- `momentum_score = 0.2` → `momentum_adj = 0.76` (trend debole → holding ridotto 24%)

### 2.3 Esempi Concreti

#### Scenario 1: Alta Convinzione
```
Input:
- risk_scalar = 1.0
- volatility = 12%
- momentum_score = 0.8

Calcolo:
- risk_adj = 0.5 + (1.0 * 0.5) = 1.0
- vol_adj = 1.0 (vol < 15%)
- momentum_adj = 0.7 + (0.8 * 0.3) = 0.94

holding_days = 90 * 1.0 * 1.0 * 0.94 = 85 giorni

Interpretazione: Scenario stabile, trend forte → holding quasi pieno (3 mesi)
```

#### Scenario 2: Media Convinzione
```
Input:
- risk_scalar = 0.5
- volatility = 18%
- momentum_score = 0.6

Calcolo:
- risk_adj = 0.5 + (0.5 * 0.5) = 0.75
- vol_adj = 0.85 (vol 15-20%)
- momentum_adj = 0.7 + (0.6 * 0.3) = 0.88

holding_days = 90 * 0.75 * 0.85 * 0.88 = 50 giorni

Interpretazione: Scenario incerto, volatilità media → holding ridotto (1.5 mesi)
```

#### Scenario 3: Bassa Convinzione
```
Input:
- risk_scalar = 0.2
- volatility = 25%
- momentum_score = 0.3

Calcolo:
- risk_adj = 0.5 + (0.2 * 0.5) = 0.6
- vol_adj = 0.7 (vol > 20%)
- momentum_adj = 0.7 + (0.3 * 0.3) = 0.79

holding_days = 90 * 0.6 * 0.7 * 0.79 = 30 giorni (clamped a min)

Interpretazione: Scenario instabile, trend debole → holding minimo (1 mese)
```

### 2.4 Logica Riesame Scenario

**Trigger riesame:**
```python
if days_held >= expected_holding_days:
    # Riesame scenario
```

**Decision tree riesame:**
```
1. Ricalcola condizioni attuali:
   - risk_scalar_current
   - volatility_current
   - momentum_score_current

2. Valuta scenario:
   IF signal_state == 'RISK_ON' AND momentum_score_current >= score_entry_min:
       # Scenario ancora favorevole
       → Calcola nuovo holding_days (con condizioni aggiornate)
       → Estendi holding: expected_exit_date = current_date + nuovo_holding
       → Log: "HOLDING_EXTENDED"
   ELSE:
       # Scenario deteriorato
       → Proponi SELL
       → Log: "EXIT_PLANNED"

3. Exit anticipato (indipendentemente da holding):
   IF signal_state == 'RISK_OFF':
       → Proponi SELL
       → Log: "EXIT_RISK_OFF"
   
   IF stop_loss_triggered:
       → Proponi SELL
       → Log: "EXIT_STOP_LOSS"
```

---

## 3. ARCHITETTURA PORTFOLIO CONSTRUCTION

### 3.1 Problema

Con N segnali RISK_ON simultanei e cash limitato, serve:
1. **Ranking**: quale candidato scegliere?
2. **Allocation**: quanto capitale allocare?
3. **Constraints**: max posizioni, cash reserve, overlap

### 3.2 Candidate Ranking

**Score composito:**
```python
candidate_score = (
    momentum_score * 0.40 +           # Trend strength (peso maggiore)
    risk_scalar * 0.30 +               # Risk-adjusted conviction
    (1 - volatility/0.30) * 0.20 +    # Stabilità (inverso vol, normalizzato)
    alpha_estimate * 0.10              # Alpha atteso vs benchmark
)
```

**Pesi (parametrizzabili in config):**
- `momentum: 0.40` → Trend è il fattore principale
- `risk_scalar: 0.30` → Convinzione risk-adjusted
- `volatility: 0.20` → Stabilità (inverso volatilità)
- `alpha: 0.10` → Alpha atteso (se disponibile)

**Output:**
- Lista candidati ordinata per `candidate_score` decrescente
- Top-N candidati selezionati (dove N dipende da cash e constraints)

### 3.3 Portfolio Constraints

#### A. Max Open Positions
```python
max_open_positions = config.get('max_open_positions', 3)  # Retail: max 3 posizioni

if current_open_positions >= max_open_positions:
    → Skip nuovi entry
    → Considera solo rebalancing posizioni esistenti
```

**Razionale:** Retail investor con portfolio €20-30k → max 3 posizioni per diversificazione senza over-diversification.

#### B. Cash Reserve
```python
min_cash_reserve_pct = config.get('min_cash_reserve_pct', 0.10)  # 10% cash minimo

available_cash = total_cash - (portfolio_value * min_cash_reserve_pct)

if available_cash < min_trade_value:
    → Skip nuovi entry
    → Attendi exit per liberare cash
```

**Razionale:** Mantenere sempre 10% cash per:
- Emergenze / opportunità
- Evitare fully invested (cash gating)
- Margine di sicurezza operativo

#### C. Position Overlap Check
```python
if symbol in current_positions:
    # Già abbiamo questa posizione
    position = current_positions[symbol]
    
    if position.days_held < position.expected_holding_days * 0.5:
        → Skip (troppo presto per aggiungere)
    
    elif candidate_score > position.entry_score * 1.2:
        → Considera ADD (scenario migliorato +20%)
    
    else:
        → Skip (scenario non abbastanza migliorato)
else:
    # Nuova posizione
    if candidate_score >= score_entry_min:
        → Entry (se cash disponibile)
```

**Razionale:**
- Non aggiungere a posizione appena aperta (evita averaging down immediato)
- Aggiungere solo se scenario migliorato significativamente (+20% score)
- Altrimenti, preferire nuove opportunità (diversificazione)

### 3.4 Capital Allocation

**Formula (per ogni candidato selezionato):**
```python
# Target weight basato su risk_scalar
target_weight = base_weight * risk_scalar  # es. 0.33 * 0.8 = 0.264

# Target value
target_value = portfolio_value * target_weight

# Qty (con rounding)
qty = int(target_value / price)

# Constraint: non superare cash disponibile
if qty * price > available_cash:
    qty = int(available_cash / price)  # Usa tutto il cash disponibile
```

**Parametri:**
- `base_weight = 1 / max_open_positions` (es. 1/3 = 0.33 per 3 posizioni max)
- `risk_scalar` → modula il peso (alta convinzione → peso pieno)

---

## 4. WORKFLOW OPERATIVO COMPLETO

### 4.1 Daily Workflow (Strategy Engine)

```
┌─────────────────────────────────────────────────────────────┐
│ STEP 1: IDENTIFICA CANDIDATI                                │
└─────────────────────────────────────────────────────────────┘
candidates = [symbol for symbol in universe if signal_state[symbol] == 'RISK_ON']

┌─────────────────────────────────────────────────────────────┐
│ STEP 2: RANKING CANDIDATI                                   │
└─────────────────────────────────────────────────────────────┘
for symbol in candidates:
    candidate_score[symbol] = calculate_candidate_score(symbol)

ranked_candidates = sorted(candidates, key=lambda s: candidate_score[s], reverse=True)

┌─────────────────────────────────────────────────────────────┐
│ STEP 3: FILTRA PER CONSTRAINTS                              │
└─────────────────────────────────────────────────────────────┘
# A. Max positions
if len(current_positions) >= max_open_positions:
    ranked_candidates = []  # Skip tutti i nuovi entry

# B. Cash reserve
available_cash = calculate_available_cash()
if available_cash < min_trade_value:
    ranked_candidates = []  # Skip tutti i nuovi entry

# C. Overlap check
final_candidates = []
for symbol in ranked_candidates:
    if symbol not in current_positions:
        final_candidates.append(symbol)  # Nuova posizione OK
    elif should_add_to_position(symbol):
        final_candidates.append(symbol)  # ADD OK
    # else: skip (overlap non giustificato)

┌─────────────────────────────────────────────────────────────┐
│ STEP 4: ALLOCAZIONE CAPITALE                                │
└─────────────────────────────────────────────────────────────┘
for symbol in final_candidates:
    if available_cash < min_trade_value:
        break  # Esaurito cash
    
    # Calcola holding period dinamico
    expected_holding_days = calculate_expected_holding_days(
        risk_scalar[symbol],
        volatility[symbol],
        momentum_score[symbol]
    )
    
    # Calcola qty
    qty = calculate_qty(symbol, available_cash, risk_scalar[symbol])
    
    if qty > 0:
        propose_order(
            symbol=symbol,
            type='BUY',
            qty=qty,
            entry_score=candidate_score[symbol],
            expected_holding_days=expected_holding_days
        )
        available_cash -= qty * price[symbol]

┌─────────────────────────────────────────────────────────────┐
│ STEP 5: RIESAME POSIZIONI ESISTENTI                         │
└─────────────────────────────────────────────────────────────┘
for position in current_positions:
    days_held = current_date - position.entry_date
    
    # A. Riesame holding period
    if days_held >= position.expected_holding_days:
        if should_extend_holding(position):
            extend_holding(position)  # Calcola nuovo holding, aggiorna expected_exit_date
        else:
            propose_order(symbol=position.symbol, type='SELL', qty=position.qty, reason='EXIT_PLANNED')
    
    # B. Exit anticipato (stop-loss)
    elif stop_loss_triggered(position):
        propose_order(symbol=position.symbol, type='SELL', qty=position.qty, reason='EXIT_STOP_LOSS')
    
    # C. Exit anticipato (RISK_OFF)
    elif signal_state[position.symbol] == 'RISK_OFF':
        propose_order(symbol=position.symbol, type='SELL', qty=position.qty, reason='EXIT_RISK_OFF')
```

### 4.2 Esempio Concreto (Multi-Candidato)

**Situazione iniziale:**
- Portfolio value: €20,000
- Cash disponibile: €5,000 (dopo reserve 10%)
- Posizioni aperte: CSSPX.MI (entry 30gg fa, holding atteso 90gg, entry_score 0.72)
- Segnali RISK_ON oggi: CSSPX.MI, XS2L.MI, EIMI.MI

**STEP 1: Identifica candidati**
```
candidates = ['CSSPX.MI', 'XS2L.MI', 'EIMI.MI']
```

**STEP 2: Ranking**
```
candidate_score['XS2L.MI'] = 0.82   (momentum 0.8, risk_scalar 0.9, vol 15%, alpha 0.05)
candidate_score['EIMI.MI'] = 0.75   (momentum 0.7, risk_scalar 0.8, vol 18%, alpha 0.03)
candidate_score['CSSPX.MI'] = 0.68  (momentum 0.6, risk_scalar 0.7, vol 16%, alpha 0.02)

ranked_candidates = ['XS2L.MI', 'EIMI.MI', 'CSSPX.MI']
```

**STEP 3: Filtra per constraints**
```
# Max positions: 1 aperta < 3 max → OK
# Cash reserve: €5,000 > min_trade_value (€2,000) → OK
# Overlap check:
  - XS2L.MI: non in portafoglio → OK
  - EIMI.MI: non in portafoglio → OK
  - CSSPX.MI: in portafoglio, days_held=30 < 45 (50% di 90) → SKIP

final_candidates = ['XS2L.MI', 'EIMI.MI']
```

**STEP 4: Allocazione capitale**
```
1. XS2L.MI:
   - expected_holding_days = 90 * 1.0 * 0.85 * 0.94 = 72 giorni
   - target_value = 20000 * 0.33 * 0.9 = €5,940
   - qty = int(5940 / 236) = 25
   - Constraint: 25 * 236 = €5,900 > €5,000 available
   → qty = int(5000 / 236) = 21
   → BUY XS2L.MI qty=21 (€4,956)
   → Cash residuo: €5,000 - €4,956 = €44

2. EIMI.MI:
   - Cash residuo €44 < min_trade_value (€2,000)
   → SKIP (cash insufficiente)
```

**STEP 5: Riesame posizioni esistenti**
```
CSSPX.MI:
  - days_held = 30 < expected_holding_days (90) → HOLD
  - No stop-loss trigger → HOLD
  - signal_state = RISK_ON → HOLD
  → Nessuna azione
```

**Risultato finale:**
- **1 nuovo entry:** XS2L.MI (21 qty, holding atteso 72gg)
- **1 posizione mantenuta:** CSSPX.MI (in holding, 60gg rimanenti)
- **Cash residuo:** €44 (sotto soglia, attende prossimo exit)

---

## 5. SCHEMA DATABASE

### 5.1 Modifiche fiscal_ledger

**Nuove colonne:**
```sql
ALTER TABLE fiscal_ledger ADD COLUMN entry_date DATE;
ALTER TABLE fiscal_ledger ADD COLUMN entry_score REAL;
ALTER TABLE fiscal_ledger ADD COLUMN expected_holding_days INTEGER;
ALTER TABLE fiscal_ledger ADD COLUMN expected_exit_date DATE;
ALTER TABLE fiscal_ledger ADD COLUMN actual_holding_days INTEGER;
ALTER TABLE fiscal_ledger ADD COLUMN exit_reason VARCHAR;
```

**Descrizione colonne:**
- `entry_date`: Data entry (per calcolare days_held)
- `entry_score`: Candidate score all'entry (per confronto in riesame)
- `expected_holding_days`: Holding calcolato all'entry
- `expected_exit_date`: Data exit pianificato (entry_date + expected_holding_days)
- `actual_holding_days`: Holding effettivo (calcolato all'exit)
- `exit_reason`: Motivo exit ('EXIT_PLANNED', 'EXIT_RISK_OFF', 'EXIT_STOP_LOSS', 'HOLDING_EXTENDED')

### 5.2 Esempio Record

**Entry (BUY):**
```
date: 2025-06-27
symbol: XS2L.MI
type: BUY
qty: 21
price: 236.00
entry_date: 2025-06-27
entry_score: 0.82
expected_holding_days: 72
expected_exit_date: 2025-09-07
actual_holding_days: NULL
exit_reason: NULL
```

**Exit (SELL pianificato):**
```
date: 2025-09-07
symbol: XS2L.MI
type: SELL
qty: 21
price: 245.00
entry_date: 2025-06-27
entry_score: 0.82
expected_holding_days: 72
expected_exit_date: 2025-09-07
actual_holding_days: 72
exit_reason: 'EXIT_PLANNED'
```

**Exit (SELL anticipato per RISK_OFF):**
```
date: 2025-08-15
symbol: XS2L.MI
type: SELL
qty: 21
price: 230.00
entry_date: 2025-06-27
entry_score: 0.82
expected_holding_days: 72
expected_exit_date: 2025-09-07
actual_holding_days: 49
exit_reason: 'EXIT_RISK_OFF'
```

---

## 6. CONFIGURAZIONE

### 6.1 Config File (etf_universe.json)

```json
{
  "portfolio_construction": {
    "max_open_positions": 3,
    "min_cash_reserve_pct": 0.10,
    "min_trade_value": 2000,
    "score_entry_min": 0.70,
    "score_add_threshold": 1.2
  },
  "holding_period": {
    "base_holding_days": 90,
    "min_holding_days": 30,
    "max_holding_days": 180
  },
  "ranking_weights": {
    "momentum": 0.40,
    "risk_scalar": 0.30,
    "volatility": 0.20,
    "alpha": 0.10
  }
}
```

### 6.2 Parametri Descrizione

**portfolio_construction:**
- `max_open_positions`: Numero massimo posizioni aperte contemporaneamente (retail: 3)
- `min_cash_reserve_pct`: Cash reserve minimo % portfolio (retail: 10%)
- `min_trade_value`: Valore minimo trade in EUR (evita micro-operazioni)
- `score_entry_min`: Score minimo per entry (filtro qualità)
- `score_add_threshold`: Soglia miglioramento score per ADD a posizione esistente (es. 1.2 = +20%)

**holding_period:**
- `base_holding_days`: Holding base (default 90 giorni = 3 mesi)
- `min_holding_days`: Holding minimo (evita overtrading)
- `max_holding_days`: Holding massimo (evita posizioni "dimenticate")

**ranking_weights:**
- `momentum`: Peso trend strength nel candidate score
- `risk_scalar`: Peso risk-adjusted conviction
- `volatility`: Peso stabilità (inverso volatilità)
- `alpha`: Peso alpha atteso vs benchmark

---

## 7. IMPATTO ATTESO

### 7.1 Execution Rate

**Attuale (senza holding period):**
- 279 RISK_ON / 251 giorni
- 9 ordini eseguiti
- Execution rate: 3.59%
- Problema: portfolio fully invested, nessun exit pianificato

**Atteso (con holding period dinamico):**
- Media holding: ~60 giorni (distribuzione 30-120gg)
- Con 3 posizioni max: ~1.5 exit/mese (60gg / 3 posizioni ≈ 1 ogni 20gg)
- Ogni exit libera cash → nuovi entry possibili
- **Execution rate atteso: 12-18%** (3-4x miglioramento)

### 7.2 Cash Rotation

**Attuale:**
- Cash medio: €-15,259 (negativo = fully invested)
- Cash min: €-19,844
- Cash max: €-1,908
- Problema: sempre fully invested, nessuna liquidità

**Atteso:**
- Cash reserve: 10% portfolio (€2,000 su €20k)
- Exit pianificati liberano cash regolarmente
- Cash disponibile per nuovi entry: €3,000-5,000 (media)
- **Cash gating: eliminato**

### 7.3 Performance

**Miglioramenti attesi:**
- **Riduzione "buy and hold involontario"**: exit pianificati evitano posizioni stagnanti
- **Migliore capital allocation**: ranking candidati → focus su migliori opportunità
- **Disciplina operativa**: riesame periodico → adattamento a scenari mutevoli
- **Turnover controllato**: holding min 30gg evita overtrading

**Rischi:**
- **Aumento turnover**: più exit → più commissioni (mitigato da holding min 30gg)
- **Timing risk**: exit pianificato potrebbe essere sub-ottimale (mitigato da riesame scenario)

---

## 8. IMPLEMENTAZIONE

### 8.1 Componenti da Modificare

1. **Schema DB** (`scripts/db/setup_db.py`)
   - Aggiungere colonne a `fiscal_ledger`

2. **Strategy Engine** (`scripts/strategy/strategy_engine.py`)
   - Funzione `calculate_expected_holding_days()`
   - Funzione `calculate_candidate_score()`
   - Funzione `rank_candidates()`
   - Funzione `filter_by_constraints()`
   - Funzione `should_add_to_position()`
   - Funzione `should_extend_holding()`
   - Workflow completo (5 step)

3. **Config** (`config/etf_universe.json`)
   - Sezioni `portfolio_construction`, `holding_period`, `ranking_weights`

4. **Backtest Engine** (`scripts/backtest/backtest_engine.py`)
   - Integrazione nuove colonne fiscal_ledger
   - Supporto exit_reason logging

5. **Execute Orders** (`scripts/trading/execute_orders.py`)
   - Passaggio parametri entry_score, expected_holding_days all'insert ledger

### 8.2 Test Plan

1. **Unit test:** Funzioni calcolo holding, candidate score, ranking
2. **Integration test:** Workflow completo strategy engine
3. **Backtest:** Run completo periodo 2025-01-05 → 2026-01-05
4. **Validation:** Verifica execution rate, cash rotation, performance vs benchmark

---

## 9. TEST PLAN BLOCCANTE

### 9.1 Golden-Run Deterministico (REPRODUCIBILITÀ)

**Obiettivo:** Stesso input → stesso output, sempre.

```python
def test_golden_run_deterministic():
    """
    Stesso DB snapshot + stessa config → stessi ordini, stesso ledger
    """
    # Setup
    db_snapshot = load_snapshot('golden_run_2025Q1.duckdb')
    config = load_config('golden_run_config.json')
    
    # Run 1
    orders_1, ledger_1 = run_backtest(db_snapshot, config, seed=42)
    
    # Run 2 (stesso input)
    orders_2, ledger_2 = run_backtest(db_snapshot, config, seed=42)
    
    # Assert: identici
    assert orders_1 == orders_2, "Orders non deterministici"
    assert ledger_1 == ledger_2, "Ledger non deterministico"
    assert hash(orders_1) == hash(orders_2), "Hash mismatch"
```

**Blocca deployment se:** Run ripetuto produce risultati diversi.

### 9.2 Property Tests su Vincoli (INVARIANTS)

**Obiettivo:** Nessuna violazione economica, mai.

```python
def test_property_no_leverage():
    """Mai leverage implicita oltre limite"""
    for date in trading_dates:
        positions_value = sum(pos.qty * pos.price for pos in positions[date])
        cash = get_cash_balance(date)
        portfolio_value = positions_value + cash
        
        # Invariant: positions <= 100% portfolio (no leverage)
        assert positions_value <= portfolio_value * 1.01, \
            f"Leverage detected: {positions_value} > {portfolio_value}"

def test_property_cash_reserve():
    """Cash mai sotto reserve minimo (dopo trade)"""
    for trade in trades:
        cash_after = get_cash_after_trade(trade)
        portfolio_value = get_portfolio_value(trade.date)
        min_reserve = portfolio_value * config['min_cash_reserve_pct']
        
        assert cash_after >= min_reserve, \
            f"Cash reserve violated: {cash_after} < {min_reserve}"

def test_property_no_oversell():
    """SELL mai > posizione disponibile"""
    for sell in sells:
        position_qty = get_position_qty(sell.symbol, sell.date)
        
        assert sell.qty <= position_qty, \
            f"Oversell: {sell.qty} > {position_qty} for {sell.symbol}"

def test_property_weight_caps():
    """Peso singola posizione mai > max_weight"""
    max_weight = 1.0 / config['max_open_positions']  # es. 33% per 3 pos
    
    for date in trading_dates:
        for pos in positions[date]:
            weight = (pos.qty * pos.price) / portfolio_value[date]
            
            assert weight <= max_weight * 1.1, \
                f"Weight cap violated: {weight:.2%} > {max_weight:.2%}"
```

**Blocca deployment se:** Qualsiasi property test fallisce.

### 9.3 Backtest Parity (COERENZA EXECUTION)

**Obiettivo:** Backtest e production usano stessa logica.

```python
def test_backtest_production_parity():
    """
    Stessa sequenza segnali → backtest_engine e execute_orders 
    producono ledger coerente (o dichiarano semplificazione)
    """
    # Setup: stessa sequenza segnali
    signals = load_signals('test_period_2025Q1')
    
    # Run backtest
    ledger_backtest = run_backtest_engine(signals, config)
    
    # Run production (simulato)
    ledger_production = simulate_production_execution(signals, config)
    
    # Assert: coerenza economica (tolleranza slippage)
    for symbol in symbols:
        pnl_backtest = calculate_pnl(ledger_backtest, symbol)
        pnl_production = calculate_pnl(ledger_production, symbol)
        
        # Tolleranza: max 2% discrepanza (slippage realistico)
        assert abs(pnl_backtest - pnl_production) / abs(pnl_backtest) < 0.02, \
            f"Backtest/production parity violated for {symbol}"
```

**Blocca deployment se:** Discrepanza > 2% senza giustificazione documentata.

### 9.4 Regression Tests (ANTI-DRIFT)

**Obiettivo:** Nessuna regressione su fix precedenti.

```python
def test_regression_price_convention():
    """Regression: adj_close per segnali, close per ledger"""
    # Verificato in v10.7.0, non deve regredire
    assert all(signal.price_type == 'adj_close' for signal in signals)
    assert all(ledger.price_type == 'close' for ledger in ledger_records)

def test_regression_fiscal_zainetto():
    """Regression: zainetto per categoria fiscale, non per simbolo"""
    # Verificato in v10.7.2, non deve regredire
    zainetto_query = get_zainetto_query()
    assert 'tax_category' in zainetto_query
    assert 'WHERE tax_category = ?' in zainetto_query

def test_regression_momentum_score():
    """Regression: score euristico 0-1, non monetario"""
    # Verificato in v10.7.8, non deve regredire
    for score in momentum_scores:
        assert 0.0 <= score <= 1.0, f"Score out of range: {score}"
        assert not isinstance(score, (int, float)) or score < 100, \
            "Score sembra monetario (€), non euristico"
```

**Blocca deployment se:** Qualsiasi regression test fallisce.

---

## 10. DECISIONI APERTE (DA RISOLVERE PRIMA DI CODING)

### 10.1 Execution Price (CRITICO)

**Domanda:** Quale prezzo usare per execution in backtest e production?

**Opzioni:**
1. **Close same-day** (conservativo, no look-ahead)
   - Pro: Semplice, coerente con segnali EOD
   - Contro: Ottimistico (assume esecuzione a close)

2. **Open next-day** (realistico)
   - Pro: Più realistico per ordini EOD
   - Contro: Richiede dati open (non sempre disponibili)

3. **Mid (close + slippage)** (pragmatico)
   - Pro: Bilancia realismo e semplicità
   - Contro: Slippage stimato, non reale

**Decisione richiesta:** [ ] Scegliere opzione e documentare in DIPF.

### 10.2 Holding Period: Reset su Rebalance? (LOGICO)

**Domanda:** Se ADD a posizione esistente, holding period si resetta?

**Opzioni:**
1. **Reset completo** (entry_date = oggi, nuovo holding)
   - Pro: Semplice, ogni ADD è un nuovo entry
   - Contro: Perde storia holding originale

2. **Weighted average** (holding pesato per qty)
   - Pro: Mantiene storia, più accurato
   - Contro: Complesso, richiede tracking multipli entry

3. **No reset** (holding originale continua)
   - Pro: Semplice, coerente con "posizione unica"
   - Contro: ADD non influenza holding (potrebbe essere sub-ottimale)

**Decisione richiesta:** [ ] Scegliere opzione e implementare coerentemente.

### 10.3 Score Composito: Range Garantito (TECNICO)

**Domanda:** Come garantire candidate_score sempre in range [0, 1]?

**Problema attuale:**
```python
score = momentum * 0.4 + risk_scalar * 0.3 + (1 - vol/0.3) * 0.2 + alpha * 0.1
```
- Se `vol > 0.3`: componente volatilità diventa negativa
- Se `alpha < 0`: componente alpha negativa
- Score finale potrebbe essere < 0 o > 1

**Soluzione proposta:**
```python
# Normalizza ogni componente in [0, 1]
vol_normalized = max(0, min(1, 1 - vol/0.3))
alpha_normalized = max(0, min(1, (alpha + 0.2) / 0.4))  # Assume alpha in [-0.2, +0.2]

score = momentum * 0.4 + risk_scalar * 0.3 + vol_normalized * 0.2 + alpha_normalized * 0.1
score = max(0.0, min(1.0, score))  # Clamp finale
```

**Decisione richiesta:** [ ] Validare range alpha e confermare normalizzazione.

### 10.4 Candidate Ranking: Multi-Entry Same Day? (OPERATIVO)

**Domanda:** Permettere più entry nello stesso giorno?

**Opzioni:**
1. **Max 1 entry/day** (conservativo)
   - Pro: Evita overtrading, semplice
   - Contro: Potrebbe perdere opportunità

2. **Multi-entry fino a cash/positions limit** (aggressivo)
   - Pro: Massimizza opportunità
   - Contro: Rischio overtrading, complessità

**Decisione richiesta:** [ ] Scegliere opzione e configurare.

### 10.5 Overlap: Underlying Duplicati (PORTFOLIO)

**Domanda:** Come gestire SP5 (S&P500) e XS2L (S&P500 leveraged)?

**Problema:** Stesso underlying, diverso leverage → overlap?

**Opzioni:**
1. **Ignora overlap** (tratta come simboli separati)
   - Pro: Semplice
   - Contro: Concentrazione rischio non gestita

2. **Penalizza score** (score *= 0.8 se overlap underlying)
   - Pro: Scoraggia overlap senza vietarlo
   - Contro: Richiede mapping underlying

3. **Vieta overlap** (max 1 per underlying)
   - Pro: Diversificazione forzata
   - Contro: Rigido, potrebbe perdere opportunità

**Decisione richiesta:** [ ] Scegliere opzione e implementare.

### 10.6 Cash Reserve: Fisso o Dinamico? (RISK MANAGEMENT)

**Domanda:** Reserve 10% fisso o adattivo a volatilità/regime?

**Opzioni:**
1. **Fisso 10%** (semplice)
   - Pro: Prevedibile, facile da implementare
   - Contro: Non adatta a scenari diversi

2. **Dinamico** (es. 5-15% basato su VIX/volatilità)
   - Pro: Adattivo a condizioni mercato
   - Contro: Complesso, richiede calibrazione

**Decisione richiesta:** [ ] Scegliere opzione e parametrizzare.

---

## 10. NEXT STEPS

1. **Revisione documento** con utente
2. **Validazione parametri** e logica
3. **Implementazione** (schema + strategy engine + config)
4. **Test** (unit + integration + backtest)
5. **Analisi risultati** (execution rate, performance, cash rotation)
6. **Iterazione** (tuning parametri se necessario)

---

**Fine Design Document**
